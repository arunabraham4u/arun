﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Retail.Business.Model.Bill
{
    /// <summary>
    /// ItemType
    /// </summary>
    public enum ItemType
    {
        Default,
        Groceries
    }
}
