﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Retail.Business.Model.Customer
{
    public enum CustomerType
    {
        Customer,
        Employee,
        Affiliate
    }
}
